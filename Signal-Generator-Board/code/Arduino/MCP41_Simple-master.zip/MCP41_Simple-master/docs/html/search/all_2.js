var searchData=
[
  ['setwiper',['setWiper',['../class_m_c_p41___simple.html#a923cfddf6a7cb916b24ed6aed6d046af',1,'MCP41_Simple']]],
  ['shutdownmode',['shutdownMode',['../class_m_c_p41___simple.html#ab742eeb1f9a5d942c41b2e7bfe262fc2',1,'MCP41_Simple']]]
];
