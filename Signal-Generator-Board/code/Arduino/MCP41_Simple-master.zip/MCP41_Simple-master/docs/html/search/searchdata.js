var indexSectionsWithContent =
{
  0: "bms",
  1: "m",
  2: "bms"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions"
};

