var searchData=
[
  ['mcp41_5fsimple',['MCP41_Simple',['../class_m_c_p41___simple.html#aa0dd75f92f6687e474eec1a5947fb762',1,'MCP41_Simple::MCP41_Simple()'],['../class_m_c_p41___simple.html#a92fc397c986192477d9cd25a3ba7692b',1,'MCP41_Simple::MCP41_Simple(SPIClass &amp;spiBus)']]]
];
