var searchData=
[
  ['begin',['begin',['../class_m_c_p41___simple.html#a54975eff1721611b6c6462542a2c484f',1,'MCP41_Simple']]]
];
