var class_m_c_p41___simple =
[
    [ "MCP41_Simple", "class_m_c_p41___simple.html#aa0dd75f92f6687e474eec1a5947fb762", null ],
    [ "MCP41_Simple", "class_m_c_p41___simple.html#a92fc397c986192477d9cd25a3ba7692b", null ],
    [ "begin", "class_m_c_p41___simple.html#a54975eff1721611b6c6462542a2c484f", null ],
    [ "setWiper", "class_m_c_p41___simple.html#a923cfddf6a7cb916b24ed6aed6d046af", null ],
    [ "shutdownMode", "class_m_c_p41___simple.html#ab742eeb1f9a5d942c41b2e7bfe262fc2", null ],
    [ "_chipSelectPin", "class_m_c_p41___simple.html#a70d149443fdb667179c52d6eed2309c8", null ],
    [ "_spiBus", "class_m_c_p41___simple.html#a692c7c8fd04329c5cda60d115330e5c3", null ]
];